.. _authors:

.. include:: ../../AUTHORS
