.. _readme:

.. include:: ../../README
